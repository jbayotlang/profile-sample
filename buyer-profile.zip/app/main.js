require.config({
  shim: {
	'bootstrap': {
		deps: ['jquery'],
		exports: '$.fn.modal'
	},
	'underscore': {
		exports: '_'
	},
	'backbone': {
		deps: ['underscore'],
		exports: 'Backbone'
	}
},
  paths: {
    eventemitter: 'bower_components/eventemitter2/lib/eventemitter2',
    aura: 'bower_components/aura/lib',
    jquery: 'bower_components/jquery/jquery',
    underscore: 'bower_components/underscore/underscore',
	backbone: 'bower_components/backbone/backbone-min',
	bootstrap: 'bower_components/bootstrap/dist/js/bootstrap.min',
	}
});

require(['aura/aura', 'bootstrap'], function (Aura) {
  'use strict';

  var app = new Aura();

  /*
  Add your extensions here.
  app.use('extensions/sample');
  */
  app.start({ components: 'body' }).then(function () {
    console.log('Aura started...');
  });
});
