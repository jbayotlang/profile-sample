define(['backbone', 'text!../templates/main.hbs.html'], function(Backbone, template) {
	'use strict';

	var view = Backbone.View.extend({
		template: template,
		initialize: function() {
			console.log('initializing comments content', this);
			this.$el.html(this.template);
		},
		render: function() {
			console.log('Comment rendered!');
		}
	});

	return view;

});
