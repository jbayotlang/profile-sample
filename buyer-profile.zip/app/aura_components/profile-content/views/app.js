define(['backbone', 'text!../templates/main.hbs.html'], function(Backbone, template) {
	'use strict';

	var view = Backbone.View.extend({
		template: template,
		initialize: function() {
			console.log('initializing profile content', this);
			this.$el.html(this.template);
		},
		render: function() {
			console.log('Profile rendered!');
		}
	});

	return view;

});
