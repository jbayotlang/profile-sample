define(['./views/app'], function(AppView) {
	'use strict';

	return {
		initialize: function() {
			var self = this;

			new AppView({
				el: self.$el
			}).render();
		}
	}

});
